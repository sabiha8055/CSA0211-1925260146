#include <stdio.h>

#define SQUARE(x) ((x) * (x))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define RUPEES_TO_PAISE(x) ((x) * 100)

static inline int square_function(int x)
{
    return x * x;
}

static inline int max_function(int a, int b)
{
    return (a > b) ? a : b;
}

int main(void)
{
    int a = 5;
    int b = 8;

    printf("Square of %d = %d\n", a, SQUARE(a));
    printf("Maximum of %d and %d = %d\n", a, b, MAX(a, b));
    printf("Rupees to paise: %d\n", RUPEES_TO_PAISE(50));
    printf("Square function: %d\n", square_function(a));
    printf("Maximum function: %d\n", max_function(a, b));
    printf("Square of a + 1 = %d\n", SQUARE(a + 1));

    return 0;
}
