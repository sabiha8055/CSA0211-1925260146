#include <stdio.h>

int main(void)
{
    int household_no = 101;
    int previous_reading = 1200;
    int current_reading = 1350;
    int units;

    const long fixed_charge_paise = 5000;
    long energy_charge_paise;
    long total_paise;

    units = current_reading - previous_reading;

    if (units <= 100)
        energy_charge_paise = 0;
    else if (units <= 200)
        energy_charge_paise = (units - 100) * 225L;
    else
        energy_charge_paise = 100 * 225L
                            + (units - 200) * 450L;

    total_paise = fixed_charge_paise + energy_charge_paise;

    printf("Household Number: %d\n", household_no);
    printf("Units Consumed: %d\n", units);
    printf("Fixed Charge: Rs. %ld.%02ld\n",
           fixed_charge_paise / 100, fixed_charge_paise % 100);
    printf("Energy Charge: Rs. %ld.%02ld\n",
           energy_charge_paise / 100, energy_charge_paise % 100);
    printf("Total Bill: Rs. %ld.%02ld\n",
           total_paise / 100, total_paise % 100);

    return 0;
}
